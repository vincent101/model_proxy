"""
tools/proxy.py — 本地路由代理，Phase 1+2+3：配置/状态基座 + HTTP 服务骨架 + 业务转发

仅使用 Python 标准库，不引入第三方依赖。
"""

import json
import logging
import os
import re
import sys
import threading
import tempfile
import urllib.error
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable

LOG_FILE = Path(__file__).parent / ".claude_proxy.log"

def _trim_log(path: Path, keep: int = 1000) -> None:
    """启动时截断日志，只保留最后 keep 行。"""
    try:
        if not path.exists():
            return
        lines = path.read_bytes().splitlines(keepends=True)
        if len(lines) > keep:
            path.write_bytes(b"".join(lines[-keep:]))
    except OSError:
        pass

_trim_log(LOG_FILE)
logging.basicConfig(
    level=logging.WARNING,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[logging.FileHandler(LOG_FILE)],
)
log = logging.getLogger(__name__)

# 默认路径
_DEFAULT_CONFIG_PATH = Path.home() / ".claude" / "proxy_config.json"
_DEFAULT_STATE_PATH = Path.home() / ".claude" / "proxy_state.json"


# ---------------------------------------------------------------------------
# ConfigStore
# ---------------------------------------------------------------------------

class ConfigStore:
    """从 proxy_config.json 加载并热重载配置。"""

    def __init__(
        self,
        config_path: str | os.PathLike | None = None,
        on_reload: Callable[[], None] | None = None,
    ):
        self._path = Path(config_path) if config_path else _DEFAULT_CONFIG_PATH
        self._config: dict[str, Any] = {}
        self._mtime: float = 0.0
        self._lock = threading.Lock()
        self._on_reload = on_reload
        self._reload()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_profiles(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._config.get("profiles", {}))

    def get_appkeys(self) -> list[str]:
        with self._lock:
            return list(self._config.get("appkeys", []))

    def get_strategies(self) -> dict[str, Any]:
        with self._lock:
            return dict(self._config.get("strategies", {}))

    def get_admin_token(self) -> str:
        with self._lock:
            return str(self._config.get("admin_token", ""))

    def get_default_url(self) -> str:
        with self._lock:
            return str(self._config.get("default_url", ""))

    def get_strategy(self, name: str) -> dict[str, Any]:
        with self._lock:
            return dict(self._config["strategies"][name])

    def maybe_reload(self) -> bool:
        """比对 mtime，有变化则重载，返回是否触发了重载。"""
        try:
            mtime = self._path.stat().st_mtime
        except FileNotFoundError:
            return False
        if mtime <= self._mtime:
            return False
        with self._lock:
            # 双重检查
            try:
                mtime = self._path.stat().st_mtime
            except FileNotFoundError:
                return False
            if mtime <= self._mtime:
                return False
            reloaded = self._reload_locked()
        # 锁外调用回调，避免锁嵌套；I4: 加载失败则不触发回调
        if reloaded and self._on_reload is not None:
            self._on_reload()
        return reloaded

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _reload(self) -> None:
        """初始化加载，失败直接上抛（不容错）。"""
        with self._lock:
            with open(self._path, "r", encoding="utf-8") as f:
                new_config: dict[str, Any] = json.load(f)
            self._mtime = self._path.stat().st_mtime
            self._config = new_config

    def _reload_locked(self) -> bool:
        """持锁加载文件，替换 config 引用。I4: 解析失败时保留旧配置，返回 False。"""
        try:
            with open(self._path, "r", encoding="utf-8") as f:
                new_config: dict[str, Any] = json.load(f)
            self._mtime = self._path.stat().st_mtime
            self._config = new_config
            return True
        except (json.JSONDecodeError, OSError) as e:
            log.warning("config reload failed, keeping old config: %s", e)
            return False


# ---------------------------------------------------------------------------
# StateStore
# ---------------------------------------------------------------------------

class StateStore:
    """持有各 strategy 的运行时游标状态，原子写盘。"""

    def __init__(
        self,
        config_store: ConfigStore,
        state_path: str | os.PathLike | None = None,
    ):
        self._cs = config_store
        self._path = Path(state_path) if state_path else _DEFAULT_STATE_PATH
        self._lock = threading.Lock()
        self._state: dict[str, Any] = {}
        self._init()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def current_appkey(self, strategy_name: str) -> str:
        """返回该 strategy 当前游标对应的 appkey（持锁读）。"""
        # 先在锁外拿 config 快照，避免锁嵌套
        strategy = self._cs.get_strategy(strategy_name)
        appkeys = self._cs.get_appkeys()
        with self._lock:
            cursor = self._state[strategy_name]["cursor"]
            idx = strategy["appkey_indices"][cursor]
            return appkeys[idx]

    def rotate(self, strategy_name: str) -> None:
        """游标前进一步（环绕），锁内完成，然后原子写盘。"""
        # 锁外先读 length，避免持 _lock 时再访问 config_store
        strategy = self._cs.get_strategy(strategy_name)
        length = len(strategy["appkey_indices"])
        with self._lock:
            cursor = self._state[strategy_name]["cursor"]
            self._state[strategy_name]["cursor"] = (cursor + 1) % length
            self._write_locked()

    def snapshot(self) -> dict[str, Any]:
        """返回 state 的浅拷贝快照（持锁）。"""
        with self._lock:
            return dict(self._state)

    def clamp_all(self, config_store: "ConfigStore | None" = None) -> None:
        """将所有 strategy 的 cursor clamp 到合法范围（reload 后调用）。
        config_store 参数支持外部传入（闭包或直接调用均可）。
        """
        cs = config_store if config_store is not None else self._cs
        # 锁外读 strategies 快照，避免锁嵌套
        strategies = cs.get_strategies()
        with self._lock:
            for sname, sval in strategies.items():
                if sname not in self._state:
                    self._state[sname] = {"cursor": 0}
                    continue
                length = len(sval["appkey_indices"])
                cursor = self._state[sname]["cursor"]
                if length == 0:
                    self._state[sname]["cursor"] = 0
                elif cursor >= length:
                    self._state[sname]["cursor"] = length - 1
            self._write_locked()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _init(self) -> None:
        """启动时初始化 state，等同于模块级 init_state。"""
        # 构建 config 快照传给 init_state，不暴露 _config 引用
        config_snapshot = {
            "strategies": self._cs.get_strategies(),
            "appkeys": self._cs.get_appkeys(),
        }
        init_state(config_snapshot, self._path, self._state)
        self._write()

    def _write(self) -> None:
        with self._lock:
            self._write_locked()

    def _write_locked(self) -> None:
        """原子写盘：写临时文件 + os.replace。"""
        dir_ = self._path.parent
        dir_.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=dir_, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self._state, f, indent=2, ensure_ascii=False)
            os.replace(tmp, self._path)
        except Exception:
            # 清理临时文件后重新抛出
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise


# ---------------------------------------------------------------------------
# init_state
# ---------------------------------------------------------------------------

def init_state(
    config: dict[str, Any],
    state_path: Path | str,
    state_out: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    初始化或恢复 state。
    - 文件不存在：每 strategy cursor=0，写盘
    - 文件已存在：加载并 clamp，不重置
    state_out 若传入则原地修改（供 StateStore 内部复用）。
    """
    state_path = Path(state_path)
    strategies: dict[str, Any] = config.get("strategies", {})

    # 尝试加载已有 state
    existing: dict[str, Any] = {}
    if state_path.exists():
        try:
            with open(state_path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except (json.JSONDecodeError, OSError):
            existing = {}

    # 构建新 state
    new_state: dict[str, Any] = {}
    for sname, sval in strategies.items():
        length = len(sval["appkey_indices"])
        if sname in existing:
            cursor = existing[sname].get("cursor", 0)
            # clamp
            if cursor >= length:
                cursor = length - 1
            if cursor < 0:
                cursor = 0
            new_state[sname] = {"cursor": cursor}
        else:
            new_state[sname] = {"cursor": 0}

    # 写入 state_out（原地复用）
    if state_out is not None:
        state_out.clear()
        state_out.update(new_state)

    # 原子写盘
    dir_ = state_path.parent
    dir_.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=dir_, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(new_state, f, indent=2, ensure_ascii=False)
        os.replace(tmp, state_path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise

    return new_state


# ---------------------------------------------------------------------------
# ProxyHandler
# ---------------------------------------------------------------------------

_CONTROL_PATH_PREFIX = "/proxy"

# I1: 只对这些状态码 failover
_FAILOVER_STATUSES = frozenset([401, 403, 429]) | frozenset(range(500, 600))

# ---------------------------------------------------------------------------
# Thinking 格式自适应缓存
# ---------------------------------------------------------------------------
import time as _time

_THINKING_FMT_CACHE: dict[str, dict] = {}          # model → {format, at}
_THINKING_CACHE_TTL = 48 * 3600                     # 48 小时


def _get_thinking_fmt(model: str) -> str | None:
    entry = _THINKING_FMT_CACHE.get(model)
    if entry and _time.time() - entry["at"] < _THINKING_CACHE_TTL:
        return entry["format"]
    return None


def _set_thinking_fmt(model: str, fmt: str) -> None:
    _THINKING_FMT_CACHE[model] = {"format": fmt, "at": _time.time()}
    log.warning("thinking_cache: model=%r → format=%r (cached 48h)", model, fmt)


def _parse_thinking_error(body: bytes) -> str | None:
    """从 400 响应体识别应换用的 thinking 格式；返回 'adaptive' 或 'enabled'，无法识别返回 None。"""
    try:
        text = body.decode("utf-8", errors="replace")
    except Exception:
        return None
    t = text.lower()
    if "thinking.type.enabled" in t and "not supported" in t:
        return "adaptive"
    if "budget_tokens" in t and "not supported" in t:
        return "adaptive"
    if "thinking.type.adaptive" in t and "not supported" in t:
        return "enabled"
    # GLM 等部分网关返回泛化错误（不含具体 thinking 关键词），
    # 当请求带了 adaptive thinking 时，转回 enabled 尝试
    # output_config 不被支持（如 haiku-4.5 不接受 adaptive 的 output_config.effort）
    if "output_config" in t and ("not permitted" in t or "not allowed" in t):
        return "enabled"
    # GLM 等部分上游返回泛化中文错误（调用方带了 thinking 才走到此分支）
    if "参数有误" in t or "invalid parameter" in t.lower():
        return "enabled"
    return None


def _apply_thinking_fmt(body: dict, fmt: str) -> dict:
    """将 body 里的 thinking/output_config 转换为目标格式，返回修改后的 body（原地修改）。"""
    thinking = body.get("thinking")
    current = thinking.get("type") if isinstance(thinking, dict) else None
    if fmt == "adaptive":
        # enabled+budget → adaptive+effort
        if current == "enabled":
            budget = thinking.get("budget_tokens", 10000)
            effort = "low" if budget < 2000 else "high" if budget >= 32000 else "medium"
            body["thinking"] = {"type": "adaptive"}
            body.setdefault("output_config", {})["effort"] = effort
    elif fmt == "enabled":
        # adaptive → enabled+budget；并清除游离的 output_config.effort
        # （haiku 等模型不接受 output_config.effort，即使 thinking 为 None 也要清）
        if current == "adaptive":
            effort = body.get("output_config", {}).get("effort", "medium")
            budget = {"low": 2000, "medium": 10000, "high": 40000}.get(effort, 10000)
            body["thinking"] = {"type": "enabled", "budget_tokens": budget}
        # 无论 thinking 形态如何，只要目标是 enabled 就移除 output_config
        # （游离的 output_config.effort 是 haiku 报错主因）
        if isinstance(body.get("output_config"), dict):
            body["output_config"].pop("effort", None)
            if not body["output_config"]:
                body.pop("output_config", None)
    return body

# 路由正则
_RE_STRATEGY_PROFILE = re.compile(
    r"^/proxy/strategy/([^/]+)/profile/([^/]+)$"
)
_RE_STRATEGY_APPKEY_NEXT = re.compile(
    r"^/proxy/strategy/([^/]+)/appkey/next$"
)


class ProxyHandler(BaseHTTPRequestHandler):
    """HTTP 请求处理器。
    实例化时需要外部注入 config_store / state_store，
    通过 server 属性访问（ThreadingHTTPServer 持有引用）。
    """

    # 静默 BrokenPipeError
    def handle_error(self, request, client_address):
        exc = sys.exc_info()[1]
        if isinstance(exc, BrokenPipeError):
            return
        super().handle_error(request, client_address)

    # 屏蔽默认日志（可按需开启）
    def log_message(self, fmt, *args):
        pass

    # ------------------------------------------------------------------
    # dispatch
    # ------------------------------------------------------------------

    def do_GET(self):
        if self.path.startswith(_CONTROL_PATH_PREFIX):
            self._dispatch_control("GET")
        else:
            self._forward("GET")

    def do_POST(self):
        if self.path.startswith(_CONTROL_PATH_PREFIX):
            self._dispatch_control("POST")
        else:
            self._forward("POST")

    def do_PUT(self):    self._forward("PUT")
    def do_DELETE(self): self._forward("DELETE")
    def do_PATCH(self):  self._forward("PATCH")

    # ------------------------------------------------------------------
    # business forwarding (Phase 3)
    # ------------------------------------------------------------------

    def _forward(self, method: str):
        cs: ConfigStore = self.server.config_store
        ss: StateStore = self.server.state_store

        # 1. maybe_reload
        cs.maybe_reload()

        # 2. strategy 匹配
        auth_header = self.headers.get("Authorization", "")
        token = ""
        if auth_header.startswith("Bearer "):
            token = auth_header[len("Bearer "):]

        strategies = cs.get_strategies()
        strategy_name: str | None = None
        for sname, sval in strategies.items():
            # I2: 跳过空 token 的 strategy，避免误匹配
            s_token = sval.get("token", "")
            if not s_token:
                continue
            if s_token == token:
                strategy_name = sname
                break

        # 未匹配 → 找 default strategy
        if strategy_name is None:
            if "default" in strategies:
                strategy_name = "default"
            else:
                log.warning("no strategy matched, 401")
                self._send_json(401, {"error": "unauthorized"})
                return

        strategy = cs.get_strategy(strategy_name)

        # 3. 读完整 body
        content_length = int(self.headers.get("Content-Length", 0) or 0)
        raw_body = self.rfile.read(content_length) if content_length > 0 else b""

        # 4. model 映射
        body_json: dict[str, Any] | None = None
        try:
            if raw_body:
                body_json = json.loads(raw_body)
        except (json.JSONDecodeError, ValueError):
            body_json = None

        profile_name = strategy.get("profile", "")
        profiles = cs.get_profiles()
        profile = profiles.get(profile_name, {})
        model_map: dict[str, str] = profile.get("models", {})

        if body_json is not None and "model" in body_json:
            orig_model = body_json["model"]
            if orig_model in model_map:
                body_json["model"] = model_map[orig_model]
            # 未命中则原样透传
            raw_body = json.dumps(body_json, ensure_ascii=False).encode("utf-8")

        # 5a. thinking 格式预转换：查缓存，命中则直接转换，避免首次失败
        # 触发条件含 output_config——haiku 等模型的报错源是游离的 output_config.effort，
        # 此时 thinking 可能为 None，不能只看 thinking 字段
        _req_model = body_json.get("model") if body_json else None
        _has_thinking_related = body_json and (body_json.get("thinking") or body_json.get("output_config"))
        if _req_model and _has_thinking_related:
            _cached_fmt = _get_thinking_fmt(_req_model)
            if _cached_fmt:
                _apply_thinking_fmt(body_json, _cached_fmt)
                raw_body = json.dumps(body_json, ensure_ascii=False).encode("utf-8")

        # 5. 构造目标 URL（剥离网关不支持的 query 参数，如 ?beta=true）
        base_url = profile.get("url", "") or cs.get_default_url()
        base_url = base_url.rstrip("/")
        _parsed = urllib.parse.urlparse(self.path)
        _qs = {k: v for k, v in urllib.parse.parse_qsl(_parsed.query) if k not in {"beta"}}
        _clean_path = _parsed.path + ("?" + urllib.parse.urlencode(_qs) if _qs else "")
        target_url = base_url + _clean_path

        # 6. failover 轮转逻辑
        failover = strategy.get("failover", "off")
        appkey_indices = strategy.get("appkey_indices", [])
        if not appkey_indices:
            self._send_error(503, f"strategy '{strategy_name}' has no appkey_indices configured")
            return
        max_tries = len(appkey_indices) if failover == "auto" else 1

        _skip_req_headers = {"host", "content-length", "authorization", "x-api-key"}

        # 记录最后一次错误响应（全部失败时回传）
        last_resp_status: int = 502
        last_resp_headers: list[tuple[str, str]] = []
        last_resp_body: bytes = b'{"error": "all upstream attempts failed"}'

        _thinking_retried = False   # thinking 格式重试只做一次
        for attempt in range(max_tries + 1):    # +1 为 thinking 重试预留
            # 每次尝试重新拿当前 appkey（rotate 后 cursor 已变）
            appkey = ss.current_appkey(strategy_name)

            # 构造转发请求头
            fwd_headers: dict[str, str] = {}
            for key, val in self.headers.items():
                if key.lower() in _skip_req_headers:
                    continue
                fwd_headers[key] = val
            fwd_headers["Authorization"] = f"Bearer {appkey}"
            fwd_headers["x-api-key"] = appkey
            fwd_headers["Content-Length"] = str(len(raw_body))

            req = urllib.request.Request(
                url=target_url,
                data=raw_body if raw_body else None,
                headers=fwd_headers,
                method=method,
            )

            # thinking 重试用掉额外的 +1 次，超出 max_tries 且未触发重试则退出
            if attempt >= max_tries and not _thinking_retried:
                break

            try:
                resp = urllib.request.urlopen(req, timeout=600)
                resp_status = resp.status
            except urllib.error.HTTPError as e:
                resp_status = e.code
                resp_headers = list(e.headers.items())
                resp_body = e.read()

                # thinking 格式错误自适应重试（仅一次，不 rotate appkey）
                # 触发条件含 output_config——haiku 报错时 thinking 可能为 None，
                # 报错源是游离的 output_config.effort
                _retry_eligible = body_json and (body_json.get("thinking") or body_json.get("output_config"))
                if resp_status == 400 and not _thinking_retried and _req_model and _retry_eligible:
                    required_fmt = _parse_thinking_error(resp_body)
                    if required_fmt:
                        _set_thinking_fmt(_req_model, required_fmt)
                        _apply_thinking_fmt(body_json, required_fmt)
                        raw_body = json.dumps(body_json, ensure_ascii=False).encode("utf-8")
                        _thinking_retried = True
                        continue  # 重试，不 rotate appkey，不计入 failover 次数

                # C1: failover 判断（thinking 重试用掉的次数不计入 failover 计数）
                _failover_attempt = attempt - (1 if _thinking_retried else 0)
                is_last = (_failover_attempt >= max_tries - 1)
                if failover == "auto" and resp_status in _FAILOVER_STATUSES and not is_last:
                    # I1: 只对 _FAILOVER_STATUSES 中的状态码 failover
                    log.warning("failover rotate: strategy=%s upstream_status=%s key_tail4=%s", strategy_name, resp_status, appkey[-4:])
                    last_resp_status = resp_status
                    last_resp_headers = resp_headers
                    last_resp_body = resp_body
                    # I3: 最后一次不 rotate
                    ss.rotate(strategy_name)
                    continue
                # 不 failover：流式回写错误响应
                self._write_buffered_response(resp_status, resp_headers, resp_body)
                return
            except (urllib.error.URLError, OSError) as e:
                # 网络异常：记录 502，轮转后继续
                last_resp_status = 502
                last_resp_headers = []
                last_resp_body = json.dumps({"error": f"upstream error: {e}"}).encode()
                if failover == "auto" and attempt < max_tries - 1:
                    # I3: 最后一次不 rotate
                    log.warning("failover rotate: strategy=%s network_error=%s key_tail4=%s", strategy_name, e, appkey[-4:])
                    ss.rotate(strategy_name)
                else:
                    break
                continue

            # C1: 2xx（或不可 failover 的状态码）→ 流式回写
            _failover_attempt = attempt - (1 if _thinking_retried else 0)
            is_last = (_failover_attempt >= max_tries - 1)
            needs_failover = (
                failover == "auto"
                and resp_status in _FAILOVER_STATUSES
                and not is_last
            )
            if needs_failover:
                # 需要 failover：关闭连接，rotate，继续下一次
                resp.close()
                last_resp_status = resp_status
                log.warning("failover rotate: strategy=%s upstream_status=%s key_tail4=%s", strategy_name, resp_status, appkey[-4:])
                # I3: 最后一次不 rotate
                ss.rotate(strategy_name)
                continue

            # 不需要 failover → 流式回写
            self._write_streaming_response(resp_status, list(resp.getheaders()), resp)
            return

        # 7. 所有 attempt 均失败，回写最后一次错误响应
        self._write_buffered_response(last_resp_status, last_resp_headers, last_resp_body)

    # ------------------------------------------------------------------
    # control API dispatch
    # ------------------------------------------------------------------

    def _dispatch_control(self, method: str):
        cs: ConfigStore = self.server.config_store
        ss: StateStore = self.server.state_store

        # 鉴权
        admin_token = cs.get_admin_token()
        if not admin_token:
            self._send_json(503, {"error": "admin_token not configured"})
            return
        request_token = self.headers.get("X-Proxy-Admin-Token", "")
        if request_token != admin_token:
            self._send_json(401, {"error": "unauthorized"})
            return

        path = self.path.split("?", 1)[0]  # 去掉 query string

        # GET /proxy/status
        if method == "GET" and path == "/proxy/status":
            self._handle_status(cs, ss)
            return

        # POST /proxy/reload
        if method == "POST" and path == "/proxy/reload":
            self._handle_reload(cs, ss)
            return

        # POST /proxy/strategy/<name>/profile/<prof>
        m = _RE_STRATEGY_PROFILE.match(path)
        if method == "POST" and m:
            self._handle_set_profile(cs, ss, m.group(1), m.group(2))
            return

        # POST /proxy/strategy/<name>/appkey/next
        m = _RE_STRATEGY_APPKEY_NEXT.match(path)
        if method == "POST" and m:
            self._handle_appkey_next(cs, ss, m.group(1))
            return

        self._send_json(404, {"error": "not found"})

    # ------------------------------------------------------------------
    # handlers
    # ------------------------------------------------------------------

    def _handle_status(self, cs: "ConfigStore", ss: "StateStore"):
        strategies = cs.get_strategies()
        appkeys = cs.get_appkeys()
        result: dict[str, Any] = {}
        state_snapshot = ss.snapshot()
        for sname, sval in strategies.items():
            cursor = state_snapshot.get(sname, {}).get("cursor", 0)
            indices = sval.get("appkey_indices", [])
            appkey_tail4 = ""
            if indices and cursor < len(indices):
                idx = indices[cursor]
                if idx < len(appkeys):
                    appkey_tail4 = appkeys[idx][-4:]
            result[sname] = {
                "profile": sval.get("profile", ""),
                "cursor": cursor,
                "current_appkey_tail4": appkey_tail4,
                "failover": sval.get("failover", ""),
            }
        self._send_json(200, {"strategies": result})

    def _handle_reload(self, cs: "ConfigStore", ss: "StateStore"):
        cs.reload()
        self._send_json(200, {"ok": True})

    def _handle_set_profile(
        self,
        cs: "ConfigStore",
        ss: "StateStore",
        strategy_name: str,
        profile_name: str,
    ):
        profiles = cs.get_profiles()
        if profile_name not in profiles:
            self._send_json(400, {"error": f"unknown profile: {profile_name}"})
            return
        strategies = cs.get_strategies()
        if strategy_name not in strategies:
            self._send_json(400, {"error": f"unknown strategy: {strategy_name}"})
            return

        # 结构化读写 proxy_config.json
        config_path = cs._path
        with cs._lock:
            with open(config_path, "r", encoding="utf-8") as f:
                raw: dict[str, Any] = json.load(f)
            if strategy_name not in raw.get("strategies", {}):
                self._send_json(400, {"error": f"strategy not found on disk: {strategy_name}"})
                return
            raw["strategies"][strategy_name]["profile"] = profile_name
            dir_ = config_path.parent
            dir_.mkdir(parents=True, exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=dir_, suffix=".tmp")
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    json.dump(raw, f, indent=2, ensure_ascii=False)
                    f.write("\n")
                os.replace(tmp, config_path)
            except Exception:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
                raise
            # 更新内存中的 config（持锁，直接调用 _reload_locked）
            cs._reload_locked()

        # 触发 clamp 回调（锁外）
        ss.clamp_all(cs)
        self._send_json(200, {"ok": True, "strategy": strategy_name, "profile": profile_name})

    def _handle_appkey_next(
        self,
        cs: "ConfigStore",
        ss: "StateStore",
        strategy_name: str,
    ):
        strategies = cs.get_strategies()
        if strategy_name not in strategies:
            self._send_json(400, {"error": f"unknown strategy: {strategy_name}"})
            return
        if not strategies[strategy_name].get("appkey_indices"):
            self._send_json(400, {"error": f"strategy '{strategy_name}' has no appkey_indices"})
            return
        ss.rotate(strategy_name)
        with ss._lock:
            new_cursor = ss._state[strategy_name]["cursor"]
        self._send_json(200, {"ok": True, "strategy": strategy_name, "cursor": new_cursor})

    # ------------------------------------------------------------------
    # helper
    # ------------------------------------------------------------------

    _SKIP_RESP_HEADERS = {"transfer-encoding", "content-length"}

    def _write_streaming_response(self, status: int, headers: list[tuple[str, str]], resp) -> None:
        """C1: 流式回写上游响应，使用 chunked 编码。"""
        self.send_response(status)
        for hname, hval in headers:
            if hname.lower() in self._SKIP_RESP_HEADERS:
                continue
            self.send_header(hname, hval)
        self.send_header("Transfer-Encoding", "chunked")
        self.end_headers()
        try:
            while True:
                chunk = resp.read(8192)
                if not chunk:
                    break
                size_line = f"{len(chunk):X}\r\n".encode("ascii")
                self.wfile.write(size_line)
                self.wfile.write(chunk)
                self.wfile.write(b"\r\n")
            self.wfile.write(b"0\r\n\r\n")
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            resp.close()

    def _write_buffered_response(self, status: int, headers: list[tuple[str, str]], body: bytes) -> None:
        """回写已完整读取的 buffer 响应（错误响应用）。"""
        self.send_response(status)
        for hname, hval in headers:
            if hname.lower() in self._SKIP_RESP_HEADERS:
                continue
            self.send_header(hname, hval)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_json(self, status: int, body: Any):
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


# ---------------------------------------------------------------------------
# ConfigStore.reload() — Phase 2 补充公有方法
# ---------------------------------------------------------------------------

# 在类定义之后 monkey-patch（避免改动类体结构）：
def _config_store_reload(self) -> None:
    """强制重载配置文件，并触发 on_reload 回调。"""
    with self._lock:
        reloaded = self._reload_locked()
    if reloaded and self._on_reload is not None:
        self._on_reload()

ConfigStore.reload = _config_store_reload  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# StateStore.init() — Phase 2 补充公有方法
# ---------------------------------------------------------------------------

def _state_store_init_public(self, config_store: "ConfigStore") -> None:
    """供 main() 在初始化时调用，功能等同于内部 _init。"""
    config_snapshot = {
        "strategies": config_store.get_strategies(),
        "appkeys": config_store.get_appkeys(),
    }
    init_state(config_snapshot, self._path, self._state)
    self._write()

StateStore.init = _state_store_init_public  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

_LOCK_FILE = Path("/tmp/claude_proxy.lock")

def main():
    config_path = _DEFAULT_CONFIG_PATH
    state_path = _DEFAULT_STATE_PATH
    port = int(os.environ.get("PROXY_PORT", "18888"))

    # 进程级互斥锁：同一时刻只允许一个 proxy.py 实例运行
    import fcntl
    lock_fd = open(_LOCK_FILE, "w")
    try:
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        existing_pid = _LOCK_FILE.read_text().strip() if _LOCK_FILE.exists() else "unknown"
        print(f"ERROR: another proxy.py is already running (pid {existing_pid}). Exiting.", flush=True)
        lock_fd.close()
        raise SystemExit(1)
    lock_fd.write(str(os.getpid()))
    lock_fd.flush()

    # 1. 实例化 ConfigStore（on_reload 稍后设置）
    config_store = ConfigStore(config_path, on_reload=None)

    # 2. 实例化 StateStore
    state_store = StateStore(config_store, state_path)

    # 3. 设置 on_reload 回调
    config_store._on_reload = lambda: state_store.clamp_all(config_store)

    # 4. 启动 ThreadingHTTPServer
    server = ThreadingHTTPServer(("127.0.0.1", port), ProxyHandler)
    server.config_store = config_store  # type: ignore[attr-defined]
    server.state_store = state_store    # type: ignore[attr-defined]

    print(f"proxy listening on 127.0.0.1:{port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
        server.server_close()


if __name__ == "__main__":
    main()
