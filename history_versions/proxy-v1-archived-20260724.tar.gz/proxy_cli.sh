#!/bin/bash
# proxy_cli.sh
# 通过 HTTP 控制 proxy.py（http://127.0.0.1:18888/proxy/*）
# 用法：proxy_cli.sh <子命令> [参数]

PROXY_PORT="${PROXY_PORT:-18888}"
PROXY_BASE="http://127.0.0.1:${PROXY_PORT}"
CONFIG_FILE="$HOME/.claude/proxy_config.json"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PID_FILE="/tmp/claude_proxy.pid"

# ---- 帮助信息 ----
print_help() {
  cat <<EOF
用法: proxy_cli.sh <子命令> [参数]

status                      显示代理运行状态 + 所有 strategy 状态
profile list                列出所有 profile
profile <name> [strategy]   切换指定 strategy 的 profile（默认 claudecode）
profile add                 交互式新增 profile
appkey list                 列出所有 appkey（尾4位脱敏）
appkey next [strategy]      轮转 appkey（默认 claudecode）
appkey add                  交互式追加 appkey
strategy list               列出所有 strategy
strategy add                交互式新增 strategy
proxy on                    启动 proxy.py
proxy off                   停止 proxy.py
migrate                     迁移 ~/.claude/settings.json 指向本地代理
--help / -h                 显示此帮助
EOF
}

# ---- 从 config 读 admin_token ----
get_admin_token() {
  python3 -c "import json,sys; print(json.load(open(sys.argv[1])).get('admin_token',''))" "$CONFIG_FILE"
}

# ---- 带鉴权的 curl 封装 ----
proxy_api() {
  local method="$1" path="$2" data="$3"
  local token
  token=$(get_admin_token)
  local args=(-s -X "$method" -H "X-Proxy-Admin-Token: $token" "$PROXY_BASE$path")
  [[ -n "$data" ]] && args+=(-H "Content-Type: application/json" -d "$data")
  curl "${args[@]}"
}

# ---- 写 config + reload ----
reload_proxy() {
  local out
  out=$(proxy_api POST /proxy/reload)
  echo "Reloaded: $out"
}

# ---- status ----
cmd_status() {
  # 代理运行状态
  if lsof -i :"$PROXY_PORT" -sTCP:LISTEN -t &>/dev/null; then
    echo "Proxy: running on port $PROXY_PORT"
  else
    echo "Proxy: NOT running on port $PROXY_PORT"
    return 1
  fi

  local out
  out=$(proxy_api GET /proxy/status)
  if [[ -z "$out" ]]; then
    echo "Error: proxy not responding"
    return 1
  fi
  echo "$out" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for name, s in data.get('strategies', {}).items():
    profile = s.get('profile', '?')
    cursor = s.get('cursor', '?')
    tail4 = s.get('current_appkey_tail4', '????')
    failover = s.get('failover', '?')
    print(f'  {name:15} profile={profile}  cursor={cursor}  appkey=...{tail4}  failover={failover}')
"
}

# ---- profile ----
cmd_profile() {
  local subcmd="$1" strategy="${2:-claudecode}"

  case "$subcmd" in
    list|"")
      # 列出所有 profile 名
      python3 -c "
import json
cfg = json.load(open('$CONFIG_FILE'))
for name in cfg.get('profiles', {}).keys():
    print(name)
"
      ;;
    add)
      echo -n "Profile name: "; read -r pname
      echo -n "URL (留空用默认): "; read -r purl
      echo "模型名请填写网关接受的完整名称，如 aws.claude-sonnet-4.6[1m]"
      echo -n "aws.claude-sonnet-4.6 对应模型 (haiku tier): "; read -r phaiku
      echo -n "aws.claude-sonnet-4.6[1m] 对应模型 (sonnet tier): "; read -r psonnet
      echo -n "aws.claude-opus-4.8[1m] 对应模型 (opus tier): "; read -r popus
      python3 -c "
import json, os, tempfile, sys
name, url, haiku, sonnet, opus = sys.argv[1:]
FILE = sys.argv[6]
cfg = json.load(open(FILE))
cfg['profiles'][name] = {
    'url': url or cfg.get('default_url', ''),
    'models': {
        'aws.claude-sonnet-4.6':     haiku,
        'aws.claude-sonnet-4.6[1m]': sonnet,
        'aws.claude-opus-4.8[1m]':   opus,
    }
}
_dir = os.path.dirname(FILE)
fd, tmp = tempfile.mkstemp(dir=_dir, suffix='.tmp')
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    os.replace(tmp, FILE)
except Exception:
    os.unlink(tmp)
    raise
print(f'Added profile: {name}')
" "$pname" "$purl" "$phaiku" "$psonnet" "$popus" "$CONFIG_FILE"
      reload_proxy
      ;;
    *)
      # profile <name> [strategy]
      local pname="$subcmd"
      local out
      out=$(proxy_api POST "/proxy/strategy/${strategy}/profile/${pname}")
      echo "$out" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(data.get('message', data))
except:
    print(sys.stdin.read())
" 2>/dev/null || echo "$out"
      ;;
  esac
}

# ---- appkey ----
cmd_appkey() {
  local subcmd="${1:-}" strategy="${2:-claudecode}"

  case "$subcmd" in
    next)
      local out
      out=$(proxy_api POST "/proxy/strategy/${strategy}/appkey/next")
      echo "$out" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print(data.get('message', data))
except:
    print(sys.stdin.read())
" 2>/dev/null || echo "$out"
      ;;
    list)
      python3 -c "
import json
cfg = json.load(open('$CONFIG_FILE'))
keys = cfg.get('appkeys', [])
for i, k in enumerate(keys):
    tail4 = str(k)[-4:]
    print(f'  [{i}] ...{tail4}')
"
      ;;
    add)
      echo -n "New appkey: "; read -r newkey
      python3 -c "
import json, os, tempfile, sys
key = sys.argv[1]
FILE = sys.argv[2]
cfg = json.load(open(FILE))
cfg.setdefault('appkeys', []).append(key)
_dir = os.path.dirname(FILE)
fd, tmp = tempfile.mkstemp(dir=_dir, suffix='.tmp')
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    os.replace(tmp, FILE)
except Exception:
    os.unlink(tmp)
    raise
print(f'Added appkey: ...{key[-4:]} (index {len(cfg[\"appkeys\"])-1})')
" "$newkey" "$CONFIG_FILE"
      reload_proxy
      ;;
    *)
      echo "用法: appkey next [strategy] | appkey list | appkey add"
      ;;
  esac
}

# ---- strategy ----
cmd_strategy() {
  local subcmd="${1:-}"

  case "$subcmd" in
    list)
      python3 -c "
import json
cfg = json.load(open('$CONFIG_FILE'))
strategies = cfg.get('strategies', {})
for name, s in strategies.items():
    indices = s.get('appkey_indices', [])
    print(f'  {name}')
    print(f'    token       : {s.get(\"token\",\"?\")}')
    print(f'    profile     : {s.get(\"profile\",\"?\")}')
    print(f'    appkey_idx  : {indices}')
    print(f'    failover    : {s.get(\"failover\",\"?\")}')
"
      ;;
    add)
      echo -n "Strategy name: "; read -r sname
      echo -n "Token: "; read -r stoken
      echo -n "Profile: "; read -r sprofile
      echo -n "Appkey indices (空格分隔, 如 0 1 2): "; read -r sindices_raw
      echo -n "Failover (auto/off): "; read -r sfailover
      python3 -c "
import json, os, tempfile, sys
name, token, profile, indices_raw, failover = sys.argv[1:6]
FILE = sys.argv[6]
cfg = json.load(open(FILE))
indices = [int(x) for x in indices_raw.split()]
n_keys = len(cfg.get('appkeys', []))
for i in indices:
    if i < 0 or i >= n_keys:
        print(f'Error: appkey index {i} out of range (0..{n_keys-1})', file=sys.stderr)
        sys.exit(1)
cfg.setdefault('strategies', {})[name] = {
    'token': token,
    'profile': profile,
    'appkey_indices': indices,
    'failover': failover
}
_dir = os.path.dirname(FILE)
fd, tmp = tempfile.mkstemp(dir=_dir, suffix='.tmp')
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    os.replace(tmp, FILE)
except Exception:
    os.unlink(tmp)
    raise
print(f'Added strategy: {name}')
" "$sname" "$stoken" "$sprofile" "$sindices_raw" "$sfailover" "$CONFIG_FILE"
      reload_proxy
      ;;
    *)
      echo "用法: strategy list | strategy add"
      ;;
  esac
}

# ---- proxy on/off/status ----
cmd_proxy() {
  local subcmd="${1:-status}"

  case "$subcmd" in
    on)
      if lsof -i :"$PROXY_PORT" -sTCP:LISTEN -t &>/dev/null; then
        echo "Proxy already running on port $PROXY_PORT"
        return
      fi
      # 清理所有残留 proxy.py 进程（可能跑在其他端口）
      local stale_pids
      stale_pids=$(pgrep -f "[p]roxy\.py" 2>/dev/null)
      if [[ -n "$stale_pids" ]]; then
        echo "Killing stale proxy process(es): $stale_pids"
        echo "$stale_pids" | xargs kill 2>/dev/null
        sleep 0.3
      fi
      nohup python3 "$SCRIPT_DIR/proxy.py" >> /tmp/claude_proxy.log 2>&1 &
      echo $! > "$PID_FILE"
      echo "Started proxy (pid $!)"
      ;;
    off)
      # 杀掉所有 proxy.py 进程（不限端口，防止孤儿进程残留）
      local all_pids
      all_pids=$(pgrep -f "[p]roxy\.py" 2>/dev/null)
      if [[ -n "$all_pids" ]]; then
        echo "$all_pids" | while read -r pid; do
          kill "$pid" 2>/dev/null && echo "Stopped proxy (pid $pid)" || echo "Failed to kill pid $pid"
        done
      else
        echo "Proxy not running"
      fi
      rm -f "$PID_FILE"
      ;;
    status)
      if lsof -i :"$PROXY_PORT" -sTCP:LISTEN -t &>/dev/null; then
        echo "Proxy: running on port $PROXY_PORT"
      else
        echo "Proxy: not running on port $PROXY_PORT"
      fi
      ;;
    *)
      echo "用法: proxy on | proxy off | proxy status"
      ;;
  esac
}

# ---- migrate ----
cmd_migrate() {
  local settings="$HOME/.claude/settings.json"
  local backup="${settings}.bak.$(date +%Y%m%d%H%M%S)"

  if [[ ! -f "$settings" ]]; then
    echo "Error: $settings not found"
    return 1
  fi

  cp "$settings" "$backup"
  echo "Backup: $backup"

  python3 -c "
import json, sys
settings_file = sys.argv[1]
cfg = json.load(open(settings_file))

env = cfg.setdefault('env', {})
env['ANTHROPIC_BASE_URL'] = 'http://localhost:18888/'
env['ANTHROPIC_AUTH_TOKEN'] = 'cc'
# 保留原有真实模型名，不做 cc-* 替换
# [1m] 模型需要 Claude Code 识别真实名称才能携带正确的 session header

if 'model' in cfg:
    pass  # 保留原 model 字段不变

json.dump(cfg, open(settings_file, 'w'), indent=2, ensure_ascii=False)
print('settings.json migrated:')
print('  ANTHROPIC_BASE_URL  -> http://localhost:18888/')
print('  ANTHROPIC_AUTH_TOKEN -> cc')
" "$settings"

  echo ""
  echo "请重启 Claude Code 生效。"
}

# ---- 主逻辑 ----
case "${1:-}" in
  --help|-h)
    print_help
    ;;
  status)
    cmd_status
    ;;
  profile)
    cmd_profile "${2:-}" "${3:-claudecode}"
    ;;
  appkey)
    cmd_appkey "${2:-}" "${3:-claudecode}"
    ;;
  strategy)
    cmd_strategy "${2:-}"
    ;;
  proxy)
    cmd_proxy "${2:-status}"
    ;;
  migrate)
    cmd_migrate
    ;;
  "")
    print_help
    ;;
  *)
    echo "Unknown command: $1. Use --help."
    exit 1
    ;;
esac
